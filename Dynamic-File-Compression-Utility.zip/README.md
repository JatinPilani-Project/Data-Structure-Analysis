# Dynamic File Compression Utility

GitHub-ready DSA project based on Huffman Coding and adaptive compression concepts.

## Features
- File Compression
- File Decompression
- Compression Ratio Analysis
- CLI Support
- DSA Concepts: Heap, Tree, HashMap, Greedy Algorithms

## Run
python main.py
