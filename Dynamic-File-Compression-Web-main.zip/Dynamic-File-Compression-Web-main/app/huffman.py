import heapq
import json
import os
from dataclasses import dataclass
from typing import Dict, Optional, Tuple


@dataclass
class Node:
    char: Optional[str]
    freq: int
    left: Optional['Node'] = None
    right: Optional['Node'] = None

    def __lt__(self, other: 'Node') -> bool:
        return self.freq < other.freq


class HuffmanCompressor:
    """DSA-based Huffman compressor for text files."""

    def __init__(self):
        self.codes: Dict[str, str] = {}
        self.reverse_codes: Dict[str, str] = {}

    def calculate_frequency(self, text: str) -> Dict[str, int]:
        frequency: Dict[str, int] = {}
        for char in text:
            frequency[char] = frequency.get(char, 0) + 1
        return frequency

    def build_heap(self, frequency: Dict[str, int]):
        heap = []
        for char, freq in frequency.items():
            heapq.heappush(heap, Node(char, freq))
        return heap

    def build_huffman_tree(self, heap):
        if len(heap) == 1:
            only_node = heapq.heappop(heap)
            return Node(None, only_node.freq, left=only_node)

        while len(heap) > 1:
            left = heapq.heappop(heap)
            right = heapq.heappop(heap)
            merged = Node(None, left.freq + right.freq, left, right)
            heapq.heappush(heap, merged)

        return heapq.heappop(heap)

    def generate_codes(self, root: Optional[Node], current_code: str = "") -> None:
        if root is None:
            return

        if root.char is not None:
            code = current_code if current_code else "0"
            self.codes[root.char] = code
            self.reverse_codes[code] = root.char
            return

        self.generate_codes(root.left, current_code + "0")
        self.generate_codes(root.right, current_code + "1")

    def encode_text(self, text: str) -> str:
        return "".join(self.codes[char] for char in text)

    def pad_encoded_text(self, encoded_text: str) -> str:
        extra_padding = 8 - (len(encoded_text) % 8)
        if extra_padding == 8:
            extra_padding = 0
        padded_info = format(extra_padding, "08b")
        return padded_info + encoded_text + ("0" * extra_padding)

    def bits_to_bytes(self, padded_encoded_text: str) -> bytes:
        byte_array = bytearray()
        for i in range(0, len(padded_encoded_text), 8):
            byte_array.append(int(padded_encoded_text[i:i + 8], 2))
        return bytes(byte_array)

    def bytes_to_bits(self, compressed_data: bytes) -> str:
        return "".join(format(byte, "08b") for byte in compressed_data)

    def remove_padding(self, padded_encoded_text: str) -> str:
        padded_info = padded_encoded_text[:8]
        extra_padding = int(padded_info, 2)
        encoded_text = padded_encoded_text[8:]
        if extra_padding:
            encoded_text = encoded_text[:-extra_padding]
        return encoded_text

    def decode_text(self, encoded_text: str) -> str:
        current_code = ""
        decoded_text = []
        for bit in encoded_text:
            current_code += bit
            if current_code in self.reverse_codes:
                decoded_text.append(self.reverse_codes[current_code])
                current_code = ""
        return "".join(decoded_text)

    def compress_file(self, input_path: str, output_folder: str) -> Tuple[str, Dict]:
        with open(input_path, "r", encoding="utf-8") as file:
            text = file.read()

        if not text:
            raise ValueError("Input file is empty. Please upload a text file with content.")

        frequency = self.calculate_frequency(text)
        heap = self.build_heap(frequency)
        root = self.build_huffman_tree(heap)
        self.generate_codes(root)

        encoded_text = self.encode_text(text)
        padded_text = self.pad_encoded_text(encoded_text)
        compressed_bytes = self.bits_to_bytes(padded_text)

        os.makedirs(output_folder, exist_ok=True)
        base_name = os.path.splitext(os.path.basename(input_path))[0]
        output_path = os.path.join(output_folder, base_name + ".huff")

        package = {
            "codes": self.codes,
            "compressed_data_hex": compressed_bytes.hex(),
            "original_filename": os.path.basename(input_path),
        }

        with open(output_path, "w", encoding="utf-8") as file:
            json.dump(package, file)

        original_size = os.path.getsize(input_path)
        compressed_size = os.path.getsize(output_path)
        ratio = (1 - compressed_size / original_size) * 100 if original_size else 0

        report = {
            "original_file": os.path.basename(input_path),
            "compressed_file": os.path.basename(output_path),
            "original_size": original_size,
            "compressed_size": compressed_size,
            "compression_ratio": round(ratio, 2),
            "unique_characters": len(frequency),
            "frequency": frequency,
            "codes": self.codes,
        }
        return output_path, report

    def decompress_file(self, compressed_path: str, output_folder: str) -> Tuple[str, Dict]:
        with open(compressed_path, "r", encoding="utf-8") as file:
            package = json.load(file)

        if not isinstance(package, dict) or "codes" not in package or "compressed_data_hex" not in package:
            raise ValueError("Invalid compressed file structure. Missing required Huffman data.")

        self.codes = package["codes"]
        self.reverse_codes = {code: char for char, code in self.codes.items()}
        
        try:
            compressed_bytes = bytes.fromhex(package["compressed_data_hex"])
        except ValueError:
            raise ValueError("Corrupted hex data in compressed package.")

        bit_string = self.bytes_to_bits(compressed_bytes)
        encoded_text = self.remove_padding(bit_string)
        decompressed_text = self.decode_text(encoded_text)

        os.makedirs(output_folder, exist_ok=True)
        base_name = os.path.splitext(os.path.basename(compressed_path))[0]
        output_path = os.path.join(output_folder, base_name + "_decompressed.txt")

        with open(output_path, "w", encoding="utf-8") as file:
            file.write(decompressed_text)

        report = {
            "compressed_file": os.path.basename(compressed_path),
            "decompressed_file": os.path.basename(output_path),
            "output_size": os.path.getsize(output_path),
            "characters_recovered": len(decompressed_text),
        }
        return output_path, report
