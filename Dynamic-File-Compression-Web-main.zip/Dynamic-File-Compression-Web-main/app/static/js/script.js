document.addEventListener("DOMContentLoaded", () => {
    const uploadZone = document.getElementById("uploadZone");
    const fileInput = document.getElementById("fileInput");
    const fileInfo = document.getElementById("fileInfo");
    const uploadForm = document.querySelector(".upload-form");

    if (uploadZone && fileInput) {
        // Drag events
        ["dragenter", "dragover"].forEach(eventName => {
            uploadZone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                uploadZone.classList.add("dragover");
            }, false);
        });

        ["dragleave", "drop"].forEach(eventName => {
            uploadZone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                uploadZone.classList.remove("dragover");
            }, false);
        });

        // Drop event
        uploadZone.addEventListener("drop", (e) => {
            const dt = e.dataTransfer;
            const files = dt.files;
            if (files.length > 0) {
                fileInput.files = files;
                updateFileInfo(files[0]);
            }
        });

        // Click on zone triggers file input
        uploadZone.addEventListener("click", () => {
            fileInput.click();
        });

        // Input change
        fileInput.addEventListener("change", (e) => {
            if (fileInput.files.length > 0) {
                updateFileInfo(fileInput.files[0]);
            }
        });
    }

    // Helper to format file size
    function formatBytes(bytes, decimals = 2) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }

    // Update the UI with selected file details
    function updateFileInfo(file) {
        if (!fileInfo) return;
        
        const name = file.name;
        const size = formatBytes(file.size);
        const ext = name.split('.').pop().toLowerCase();
        
        fileInfo.style.display = "block";
        fileInfo.innerHTML = `<strong>Selected File:</strong> ${name} (${size})`;
        
        // Dynamic feedback styling
        const textElement = uploadZone.querySelector(".upload-text");
        if (textElement) {
            textElement.textContent = "File selected successfully!";
            textElement.style.color = "var(--secondary-color)";
        }
    }
});
