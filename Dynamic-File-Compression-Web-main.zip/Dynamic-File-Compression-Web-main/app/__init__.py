import os
from flask import Flask


def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = "change-this-secret-key"
    
    # Use absolute paths based on the project root folder (parent of 'app')
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    app.config["UPLOAD_FOLDER"] = os.path.join(project_root, "uploads")
    app.config["COMPRESSED_FOLDER"] = os.path.join(project_root, "compressed_files")
    app.config["DECOMPRESSED_FOLDER"] = os.path.join(project_root, "decompressed_files")
    app.config["OUTPUT_FOLDER"] = os.path.join(project_root, "outputs")
    app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024

    from .routes import main_bp
    app.register_blueprint(main_bp)
    return app

