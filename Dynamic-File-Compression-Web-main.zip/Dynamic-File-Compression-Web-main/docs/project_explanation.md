# Project Explanation

Dynamic File Compression Utility is a web-based DSA project that compresses text files using Huffman Coding.

## Workflow

Input file -> frequency calculation -> min heap -> Huffman tree -> code generation -> compression -> decompression -> original recovery.

## DSA Concepts

- HashMap for character frequency
- Min Heap for selecting two minimum-frequency nodes
- Binary Tree for Huffman Tree
- Recursion for code generation
- Greedy algorithm for optimal prefix code construction
- File handling for upload, compression, download, and decompression
